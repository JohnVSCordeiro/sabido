package com.example.springboot.controllers;

import com.example.springboot.dtos.PlacarRecordsDto;
import com.example.springboot.model.PlacarModel;
import com.example.springboot.repositories.PlacarRepository;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/placar")
public class PlacarController {

    @Autowired
    private PlacarRepository placarRepository;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<PlacarModel> savePlacar(@RequestBody @Valid PlacarRecordsDto placarRecordsDto) {
        PlacarModel placarModel = new PlacarModel();
        BeanUtils.copyProperties(placarRecordsDto, placarModel);
        return ResponseEntity.status(HttpStatus.CREATED).body(placarRepository.save(placarModel));
    }

    @GetMapping
    public ResponseEntity<List<PlacarModel>> getAllPlacar() {
        List<PlacarModel> placares = placarRepository.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(placares);
    }
}
